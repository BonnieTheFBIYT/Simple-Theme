1 Go To Auto Dark Mode And Click Personalization And For Light Theme "Windows 11 Light" And For Dark Theme "Windows 11 Dark"

2 Go to https://www.microsoft.com/en-us/p/roundedtb/9mtftxsj9m7f?activetab=pivot:overviewtab And Download The RoundedTB Program And Click Advanced And Click Dynamic (the margin is 3 and corner radius is 7)